"""Local comparison of post-render percentile algorithms. Not a renderer or a PR."""
import hashlib, json, os, sys, glob, time
import numpy as np
from PIL import Image

BLOCK_PIXELS = 1 << 18
PR_BLOCK_PIXELS = 1 << 22

def histogram_p95(comp):
    # Unknown releases use the reference path. 2.5.2 branch is derived from
    # the published source and MUST be verified in that environment.
    if (np.__version__ not in ('2.3.5', '2.5.2') or comp.dtype.kind != 'u'
            or comp.dtype.itemsize > 2 or not comp.flags.c_contiguous or not comp.size):
        return np.percentile(comp.astype(np.float32), 95)
    hist = np.zeros(1 << (8 * comp.dtype.itemsize), dtype=np.int64)
    flat = comp.reshape(-1)
    for i in range(0, flat.size, BLOCK_PIXELS):
        hist += np.bincount(flat[i:i+BLOCK_PIXELS], minlength=hist.size)
    cdf = hist.cumsum()
    if np.__version__ == '2.3.5':
        rank = (flat.size - 1) * np.true_divide(95, np.float32(100))
        lo = min(int(rank), flat.size - 1)
        gamma = np.asarray(rank - lo, dtype=np.asarray(rank).dtype)
    else:  # NumPy 2.5.2: double precision rank and weak Python scalar interpolation
        rank = (flat.size - 1) * np.true_divide(95, 100)
        lo = min(int(rank), flat.size - 1)
        gamma = float(rank - lo)
    hi = min(lo+1, flat.size-1)
    x, y = np.searchsorted(cdf, [lo, hi], side='right')
    return np.quantile(np.array([x, y], dtype=np.float32), gamma)

def reference(comp):
    strip=comp.astype(np.float32)
    p95=np.percentile(strip,95)
    strip=np.clip(strip/p95,0,1)*255 if p95>0 else strip
    return strip.astype(np.uint8),p95

def pr_p95(comp):
    # From PR #2446, head 6222de0749401a4209b35453d1989de62d9ce2a6.
    lower=np.percentile(comp,95,method='lower')
    if lower==np.percentile(comp,95,method='higher'):
        return np.float32(lower)
    return np.percentile(comp.astype(np.float32),95,overwrite_input=True)

def candidate_scale(comp, method):
    p95=(histogram_p95 if method=='histogram' else pr_p95)(comp)
    lut=np.arange(np.iinfo(comp.dtype).max+1,dtype=np.float32)
    lut=(np.clip(lut/p95,0,1)*255 if p95>0 else lut).astype(np.uint8)
    strip8=np.empty(comp.shape,np.uint8)
    src,dst=comp.reshape(-1),strip8.reshape(-1)
    # Same block size as competing PR, isolate percentile algorithm only.
    for i in range(0,src.size,PR_BLOCK_PIXELS):
        np.take(lut,src[i:i+PR_BLOCK_PIXELS],out=dst[i:i+PR_BLOCK_PIXELS])
    return strip8,p95

def compare(a,label,kind):
    expect,p=reference(a)
    candidate,q=candidate_scale(a,'histogram')
    competing,r=candidate_scale(a,'pr2446')
    d=int(np.count_nonzero(expect!=candidate)); e=int(np.count_nonzero(expect!=competing))
    out=dict(label=label,kind=kind,shape=list(a.shape),dtype=str(a.dtype),reference_p95=float(p),histogram_p95=float(q),pr_p95=float(r),histogram_changed=d,pr_changed=e,histogram_p95_exact=p.tobytes()==q.tobytes(),pr_p95_exact=p.tobytes()==r.tobytes(),reference_sha256=hashlib.sha256(expect.tobytes()).hexdigest())
    print(json.dumps(out),flush=True)
    assert d==0 and p.tobytes()==q.tobytes(),out

def run(root):
    print(json.dumps({'numpy':np.__version__,'python':sys.version}),flush=True)
    # Controlled numerical stress cases, not real scroll data.
    for n in [16777218,22192000,22192001,33554435]:
        k=int((n-1)*0.95)
        for delta in [-1,0,1]:
            a=np.full(n,200,np.uint8); a[:k+delta]=0
            compare(a,f'boundary_n{n}_delta{delta}','synthetic')
    # Real previously supplied predictions, not fresh CT layers.
    for p in sorted(glob.glob(os.path.join(root,'z*.tif'))):
        with Image.open(p) as im:a=np.array(im)
        compare(a,os.path.basename(p),'prediction_tiff')
    # Previously supplied CT atlas views; not raw TIFF layer stacks.
    for name in ['ct_mid.png','1000020581.png','1000020567.png']:
        p=os.path.join(root,name)
        if os.path.isfile(p):
            with Image.open(p) as im:a=np.array(im.convert('L'))
            compare(a,name,'ct_view_grayscale')

if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else '/mnt/data')
