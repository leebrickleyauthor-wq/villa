"""Compare the post-render image path, not the 3D renderer itself."""
import argparse, hashlib, json, os, pathlib, statistics, subprocess, sys, tempfile, time, urllib.request
import numpy as np
from PIL import Image
from validate import reference, candidate_scale

Image.MAX_IMAGE_PIXELS = None
ROOT = 'https://vesuvius-challenge-open-data.s3.us-east-1.amazonaws.com/PHerc0139/segments/20250731185658-z_dbg_gen_09900/surface-volumes/9.362um-1.2m-113keV-volume-20250728140407.tifs/'
BLOCK = 1 << 22

def fetch_layers(dest):
    dest.mkdir(parents=True, exist_ok=True)
    total = 0
    for i in range(5):
        name = f'{i:02d}.tif'; url = ROOT + name; p = dest / name
        if not p.exists():
            tmp = p.with_suffix('.partial')
            try:
                with urllib.request.urlopen(url, timeout=60) as resp, tmp.open('wb') as f:
                    while data := resp.read(1 << 20):
                        total += len(data)
                        if total > 500 * 1024**2: raise RuntimeError('500 MiB download budget exceeded')
                        f.write(data)
                with Image.open(tmp) as im: im.verify()
                tmp.replace(p)
            finally:
                tmp.unlink(missing_ok=True)
        print(f'{url} -> {p.stat().st_size} bytes', flush=True)
    return [str(dest / f'{i:02d}.tif') for i in range(5)]

def composite(paths, method):
    comp = None
    for path in paths:
        with Image.open(path) as im:
            if method == 'main':
                layer = np.asarray(im)
                if comp is not None and (comp.shape != layer.shape or comp.dtype != layer.dtype):
                    raise ValueError('Mismatched layer shape/dtype')
                comp = layer if comp is None else np.maximum(comp, layer)
            else:
                im.load(); w,h = im.size
                if comp is not None and (first != (im.mode,im.size)): raise ValueError('Mismatched layers')
                first = (im.mode, im.size)
                rows = max(1, BLOCK//w)
                for y in range(0,h,rows):
                    band = np.asarray(im.crop((0,y,w,min(h,y+rows))))
                    if comp is None:
                        comp = np.zeros((h,w),band.dtype)
                    np.maximum(comp[y:y+rows],band,out=comp[y:y+rows])
    return comp

def rss():
    return {s.split(':')[0]: int(s.split()[1]) for s in open('/proc/self/status') if s.startswith(('VmRSS:', 'VmHWM:'))}

def worker(method, paths):
    # Linux only; fresh process per trial. Peak covers decoding, scaling and writing.
    with open('/proc/self/clear_refs','w') as f: f.write('5\n')
    start = rss()['VmRSS']; t = time.perf_counter()
    comp = composite(paths, method)
    if comp.dtype.kind != 'u' or comp.dtype.itemsize > 2: raise ValueError('Expected uint8/uint16 grayscale')
    shape = list(comp.shape); dtype = str(comp.dtype)
    if method == 'main':
        # Preserve main's float strip and composite lifetime through JPEG writing.
        strip = comp.astype(np.float32); p = np.percentile(strip,95)
        strip = np.clip(strip/p,0,1)*255 if p>0 else strip
        out = strip.astype(np.uint8)
    else:
        out,p = candidate_scale(comp, 'pr2446' if method == 'pr2446' else 'histogram'); del comp
    # Hash without constructing a full-size bytes copy.
    digest = hashlib.sha256(memoryview(out)).hexdigest()
    jpgs = []
    with tempfile.TemporaryDirectory() as d:
        for i,x in enumerate(range(0,out.shape[1],16384)):
            dest = pathlib.Path(d)/f'{i:03}.jpg'
            Image.fromarray(out[:,x:x+16384]).save(dest,quality=95)
            with dest.open('rb') as f: jpgs.append(hashlib.file_digest(f,'sha256').hexdigest())
    elapsed = time.perf_counter()-t; peak = rss()['VmHWM']
    print(json.dumps(dict(method=method,numpy=np.__version__,shape=shape,dtype=dtype,layers=len(paths),p95=float(p),p95_bytes=p.tobytes().hex(),pixels_sha256=digest,jpeg_sha256=jpgs,seconds=elapsed,peak_mib=peak/1024,additional_mib=(peak-start)/1024)))

def benchmark(paths, label, repeats, report):
    rows=[]
    for k in range(repeats):
        for method in ['main','pr2446','histogram'][k%3:]+['main','pr2446','histogram'][:k%3]:
            r=json.loads(subprocess.check_output([sys.executable,__file__,'--worker',method,*paths],text=True))
            rows.append(r); print(json.dumps(r),flush=True)
    baseline=rows[0]; equal=all(r['pixels_sha256']==baseline['pixels_sha256'] and r['jpeg_sha256']==baseline['jpeg_sha256'] and r['p95_bytes']==baseline['p95_bytes'] for r in rows)
    summary={m:{key:statistics.median(r[key] for r in rows if r['method']==m) for key in ['seconds','additional_mib','peak_mib']} for m in ['main','pr2446','histogram']}
    result=dict(label=label,source_paths=paths,numpy=np.__version__,equal=equal,summary=summary,trials=rows)
    pathlib.Path(report).write_text(json.dumps(result,indent=2)); print(json.dumps(dict(equal=equal,summary=summary),indent=2)); return result

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--worker',choices=['main','pr2446','histogram']); ap.add_argument('--download',action='store_true'); ap.add_argument('--repeats',type=int,default=2); ap.add_argument('--report',default='report.json'); ap.add_argument('paths',nargs='*'); args=ap.parse_args()
    if args.worker: worker(args.worker,args.paths)
    else:
        paths=fetch_layers(pathlib.Path('pherc0139_layers')) if args.download else args.paths
        if not paths: ap.error('Provide TIFF paths or --download')
        benchmark(paths,'official pre-rendered PHerc0139 CT layers' if args.download else 'user-supplied files, not verified CT layers',args.repeats,args.report)
